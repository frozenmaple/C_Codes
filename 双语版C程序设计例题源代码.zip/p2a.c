 int main()
 { 
   int v1 ; 
   float v2 ; 
   char v3 ; 
   v1 = 65 ; 
   v2 = -18.23 ; 
   v3 = 'a'; 
   return 0 ;
 } 

