 /* Program example P4D
    To input a single character and display it. */ 
 #include <stdio.h> 
 int main() 
 { 
   char ch ; 
 
   printf( "Press a key and then press Enter " ) ; 
   scanf( " %c", &ch ) ; 
   printf( "You pressed the %c key\n", ch ) ;
   return 0 ; 
 } 

