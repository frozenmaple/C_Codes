 #include <stdio.h> 
 int main()
 { 
   int v1 ; 
   float v2 ; 
   char v3 ; 
   v1 = 65 ; 
   v2 = -18.23 ; 
   v3 = 'a' ; 
   printf( "v1 has the value %d\n", v1 ) ; 
   printf( "v2 has the value %f\n", v2 ) ; 
   printf( "v3 has the value %c\n", v3 ) ; 
   printf( "End of program\n" ) ;
   return 0 ;
 }

