//demo for null string's length
#include<stdio.h>
#include<string.h>

int main()
{
	char s[] = {0};
	printf("%d",strlen(s));
	return 0;
}

